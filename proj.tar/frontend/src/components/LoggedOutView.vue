<template>
  <div align="center" class="mx-auto text-h3">Login or register to use WeightBook</div>
</template>

<script setup lang="ts"></script>
