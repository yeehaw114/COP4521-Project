export type User = {
  username: string
  email: string
  id: number
}
