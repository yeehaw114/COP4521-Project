<template>
  <v-card class="mx-auto pa-6" elevation="15" max-width="800" rounded="md">
    <div>
      <div align="center" class="mx-auto text-h3">About Us</div>
      <v-card class="mx-auto pa-6" max-width="750" rounded="md">
        <div class="text-h6">
          Contributors: Alex Gonzalez, Zachary Lima, Gavin McDavitt, Ethan Burke, Zachary Herman,
          Fernando de Torres
        </div>
        <div class="text-body-1">
          This is a project made for COP 4521 at Florida State University. We used Vue.js with
          Vuetify components for the frontend. We used Django for the backend along with a
          PostgreSQL database. Additionally, we containerized the entire application using Docker.
        </div>
      </v-card>
    </div>
  </v-card>
</template>

<script setup lang="ts"></script>

<style scoped></style>
