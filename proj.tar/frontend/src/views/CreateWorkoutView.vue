<template>
  <CreateWorkout />
</template>

<script setup lang="ts">
import CreateWorkout from '@/components/CreateWorkout.vue'
</script>

<style scoped></style>
